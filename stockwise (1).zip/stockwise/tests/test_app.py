"""Automated tests for StockWise. Run with:  pytest -v

Test IDs (TC-xx) map to the test-case table in the final report.
"""
import os
import re
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import create_app, get_db  # noqa: E402


@pytest.fixture
def app(tmp_path):
    return create_app({"TESTING": True, "SECRET_KEY": "test-key",
                       "DATABASE": str(tmp_path / "test.db"), "CSRF_ENABLED": False})


@pytest.fixture
def client(app):
    return app.test_client()


def register(c, user="admin1", pw="Passw0rd!"):
    return c.post("/register", data={"username": user, "password": pw})


def login(c, user="admin1", pw="Passw0rd!"):
    return c.post("/login", data={"username": user, "password": pw},
                  follow_redirects=True)


@pytest.fixture
def admin(client):
    register(client)
    login(client)
    return client


def add_item(c, sku="PEN-1", name="Ballpen", qty="10", level="5", **extra):
    data = {"sku": sku, "name": name, "category": "Office", "unit": "pcs",
            "quantity": qty, "reorder_level": level}
    data.update(extra)
    return c.post("/items/new", data=data, follow_redirects=True)


def item_row(app, sku):
    with app.app_context():
        return dict(get_db().execute("SELECT * FROM items WHERE sku=?", (sku,)).fetchone())


# ---- Authentication (FR-01, FR-02, NFR-01) -------------------------------
def test_tc01_register_valid(client):
    r = register(client)
    assert r.status_code == 302 and "/login" in r.headers["Location"]


def test_tc02_register_short_password_rejected(client):
    r = register(client, pw="short")
    assert r.status_code == 400
    assert b"at least 8 characters" in r.data


def test_tc03_register_bad_username_rejected(client):
    r = register(client, user="a!")
    assert r.status_code == 400
    assert b"Username must be" in r.data


def test_tc04_duplicate_username_rejected(client):
    register(client)
    r = register(client)
    assert r.status_code == 400 and b"already taken" in r.data


def test_tc05_password_is_hashed(app, client):
    register(client)
    with app.app_context():
        h = get_db().execute("SELECT password_hash FROM users").fetchone()[0]
    assert h != "Passw0rd!" and "Passw0rd!" not in h


def test_tc06_login_success(client):
    register(client)
    r = login(client)
    assert b"Dashboard" in r.data


def test_tc07_login_wrong_password(client):
    register(client)
    r = client.post("/login", data={"username": "admin1", "password": "nope"})
    assert r.status_code == 401 and b"Invalid username or password" in r.data


def test_tc08_protected_page_requires_login(client):
    r = client.get("/items")
    assert r.status_code == 302 and "/login" in r.headers["Location"]


# ---- Item management (FR-03 .. FR-06) ------------------------------------
def test_tc09_add_item_valid(admin, app):
    r = add_item(admin)
    assert b"Item added" in r.data
    assert item_row(app, "PEN-1")["quantity"] == 10


def test_tc10_add_item_missing_name(admin):
    r = add_item(admin, name="")
    assert r.status_code == 400 and b"Name is required" in r.data


def test_tc11_add_item_negative_quantity(admin):
    r = add_item(admin, qty="-5")
    assert r.status_code == 400 and b"between 0 and" in r.data


def test_tc12_add_item_non_numeric_quantity(admin):
    r = add_item(admin, qty="abc")
    assert r.status_code == 400 and b"whole number" in r.data


def test_tc13_duplicate_sku_rejected(admin):
    add_item(admin)
    r = add_item(admin, name="Other")
    assert r.status_code == 400 and b"SKU already exists" in r.data


def test_tc14_edit_item(admin, app):
    add_item(admin)
    iid = item_row(app, "PEN-1")["id"]
    r = admin.post(f"/items/{iid}/edit", data={
        "sku": "PEN-1", "name": "Blue Pen", "category": "Office",
        "unit": "pcs", "reorder_level": "7"}, follow_redirects=True)
    assert b"Item updated" in r.data
    assert item_row(app, "PEN-1")["name"] == "Blue Pen"


def test_tc15_delete_item(admin, app):
    add_item(admin)
    iid = item_row(app, "PEN-1")["id"]
    r = admin.post(f"/items/{iid}/delete", follow_redirects=True)
    assert b"Item deleted" in r.data


def test_tc16_search_filters_items(admin):
    add_item(admin, sku="A1", name="Apple")
    add_item(admin, sku="B1", name="Banana")
    r = admin.get("/items?q=banana")
    assert b"Banana" in r.data and b"Apple" not in r.data


def test_tc17_unknown_item_404(admin):
    assert admin.get("/items/9999").status_code == 404


# ---- Stock in / out (FR-07, FR-08) ---------------------------------------
def test_tc18_stock_in_increases_quantity(admin, app):
    add_item(admin)
    iid = item_row(app, "PEN-1")["id"]
    admin.post(f"/items/{iid}/stock", data={"movement_type": "IN", "quantity": "5"})
    assert item_row(app, "PEN-1")["quantity"] == 15


def test_tc19_stock_out_decreases_quantity(admin, app):
    add_item(admin)
    iid = item_row(app, "PEN-1")["id"]
    admin.post(f"/items/{iid}/stock", data={"movement_type": "OUT", "quantity": "4"})
    assert item_row(app, "PEN-1")["quantity"] == 6


def test_tc20_stock_out_more_than_available_rejected(admin, app):
    add_item(admin)
    iid = item_row(app, "PEN-1")["id"]
    r = admin.post(f"/items/{iid}/stock", data={"movement_type": "OUT", "quantity": "99"},
                   follow_redirects=True)
    assert b"Not enough stock" in r.data
    assert item_row(app, "PEN-1")["quantity"] == 10


def test_tc21_zero_or_negative_movement_rejected(admin, app):
    add_item(admin)
    iid = item_row(app, "PEN-1")["id"]
    for bad in ("0", "-3", "x", ""):
        admin.post(f"/items/{iid}/stock", data={"movement_type": "IN", "quantity": bad})
    assert item_row(app, "PEN-1")["quantity"] == 10


def test_tc22_movement_is_logged(admin, app):
    add_item(admin)
    iid = item_row(app, "PEN-1")["id"]
    admin.post(f"/items/{iid}/stock", data={"movement_type": "OUT", "quantity": "2",
                                            "note": "Class use"})
    r = admin.get("/movements")
    assert b"Class use" in r.data


# ---- Low-stock alerts and reports (FR-09, FR-10) -------------------------
def test_tc23_low_stock_warning_after_stock_out(admin, app):
    add_item(admin)  # qty 10, reorder 5
    iid = item_row(app, "PEN-1")["id"]
    r = admin.post(f"/items/{iid}/stock", data={"movement_type": "OUT", "quantity": "6"},
                   follow_redirects=True)
    assert b"Low stock" in r.data


def test_tc24_low_stock_report_lists_only_low_items(admin):
    add_item(admin, sku="LOW1", name="Lowitem", qty="2", level="5")
    add_item(admin, sku="OK1", name="Okitem", qty="50", level="5")
    r = admin.get("/reports/low-stock")
    assert b"Lowitem" in r.data and b"Okitem" not in r.data


def test_tc25_csv_export(admin):
    add_item(admin)
    r = admin.get("/reports/inventory.csv")
    assert r.mimetype == "text/csv" and b"PEN-1" in r.data


def test_tc26_csv_neutralizes_formula_injection(admin):
    add_item(admin, sku="F1", name="=SUM(A1)")
    r = admin.get("/reports/inventory.csv")
    assert b"'=SUM(A1)" in r.data


# ---- Security and authorization (NFR-02, NFR-03) -------------------------
def test_tc27_staff_cannot_add_items(client):
    register(client)                       # first user = admin
    client.post("/logout")
    register(client, user="staff1")        # second user = staff
    login(client, user="staff1")
    assert client.get("/items/new").status_code == 403


def test_tc28_xss_is_escaped(admin):
    add_item(admin, sku="X1", name="<script>alert(1)</script>")
    r = admin.get("/items")
    assert b"<script>alert(1)</script>" not in r.data
    assert b"&lt;script&gt;" in r.data


def test_tc29_sql_injection_in_search_is_harmless(admin):
    add_item(admin)
    r = admin.get("/items?q=' OR 1=1 --")
    assert r.status_code == 200 and b"No records found" in r.data


def test_tc30_csrf_blocks_post_without_token(tmp_path):
    app = create_app({"TESTING": True, "SECRET_KEY": "k",
                      "DATABASE": str(tmp_path / "c.db"), "CSRF_ENABLED": True})
    c = app.test_client()
    r = c.post("/register", data={"username": "abc", "password": "Passw0rd!"})
    assert r.status_code == 400


def test_tc31_csrf_allows_post_with_token(tmp_path):
    app = create_app({"TESTING": True, "SECRET_KEY": "k",
                      "DATABASE": str(tmp_path / "c.db"), "CSRF_ENABLED": True})
    c = app.test_client()
    page = c.get("/register").get_data(as_text=True)
    token = re.search(r'name="csrf_token" value="([0-9a-f]+)"', page).group(1)
    r = c.post("/register", data={"username": "abc", "password": "Passw0rd!",
                                  "csrf_token": token})
    assert r.status_code == 302


def test_tc32_error_page_hides_internals(admin):
    r = admin.get("/items/9999")
    assert b"Traceback" not in r.data and b"not found" in r.data.lower()
