# StockWise - Inventory Monitoring System

**Current version:** v1.0.0

StockWise is a small web app that helps school supply rooms, labs and small shops keep track of
what they have, record stock going in and out, and get warned when items run low.

## Team members
<!-- TODO: replace with your team name, members and student numbers -->
| Name | Role |
|------|------|
| _Member 1_ | Project Manager / Scrum Master |
| _Member 2_ | Lead Developer |
| _Member 3_ | QA / Test Lead |

## Features (MVP)
1. **Item management** - add, edit, delete, search and filter items (admin only for changes).
2. **Stock In / Stock Out logging** - every change is recorded with user, time and note; stock can never go negative.
3. **Low-stock alerts** - dashboard panel, warning after a stock-out, and a low-stock report.
4. **Reports** - movement history and CSV export of the inventory.
5. **Accounts and roles** - admin and staff, with hashed passwords.

## Technology stack
- Python 3.10+ and Flask (web framework, chosen for being small and easy to explain)
- SQLite (no server to set up, free to host)
- Jinja2 templates, plain CSS
- pytest for automated tests

## Setup and installation
Prerequisites: Python 3.10 or newer and Git.

```bash
git clone <your-repo-url> stockwise
cd stockwise
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # then edit SECRET_KEY
python seed.py                   # optional: fictional demo data
python app.py                    # open http://127.0.0.1:5000
```

Demo accounts created by `seed.py` (dummy credentials, local use only):
`admin_demo` / `DemoPass123` (admin) and `staff_demo` / `DemoPass123` (staff).
If you skip `seed.py`, the first account you register becomes the admin.

Load `.env` values with your shell (`export $(grep -v '^#' .env | xargs)`) or set
`SECRET_KEY` in your hosting platform's secrets feature.

### Run the tests
```bash
pytest -v
```

## Deployment
Not yet deployed publicly. Local-run instructions above are the reproducible method.
For a free host (e.g. Render): build `pip install -r requirements.txt`, start
`gunicorn "app:create_app()"` (add `gunicorn` to requirements), and set `SECRET_KEY` as a secret.
Note SQLite files on free tiers may be wiped on redeploy; export backups regularly.

## Backup
Copy the SQLite file while the app is idle: `cp stockwise.db backups/stockwise-$(date +%F).db`.
Restore by stopping the app and copying a backup over `stockwise.db`.

## Known limitations
- No email or SMS notifications; alerts appear only inside the app.
- No password reset; an admin must be recreated if the only admin forgets their password.
- No pagination beyond the latest 200 movements.
- Single-site, single-database; not designed for concurrent heavy use.
- Tested with automated tests and manual checks in Chrome only (update this once you test more).

## License / usage note
Educational project for a Software Engineering course. Not licensed for commercial use.
