"""StockWise - Inventory Monitoring System (v1.0.0).

A small Flask + SQLite app for school supply rooms, labs and small shops.
Core features: item records, stock in/out logging, low-stock alerts, reports.
"""
import csv
import io
import logging
import os
import secrets
import sqlite3
from functools import wraps

from flask import (Flask, Response, abort, flash, g, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

__version__ = "1.0.0"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MAX_QTY = 1_000_000
MAX_TEXT = 100


# --------------------------------------------------------------------------
# App factory
# --------------------------------------------------------------------------
def create_app(test_config=None):
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", ""),
        DATABASE=os.environ.get("DATABASE", os.path.join(BASE_DIR, "stockwise.db")),
        CSRF_ENABLED=True,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
    )
    if test_config:
        app.config.update(test_config)
    if not app.config["SECRET_KEY"]:
        # Random per-process key: safe default, sessions reset on restart.
        app.config["SECRET_KEY"] = secrets.token_hex(32)

    logging.basicConfig(level=logging.INFO)
    app.teardown_appcontext(close_db)
    with app.app_context():
        init_db()

    register_hooks(app)
    register_routes(app)
    return app


# --------------------------------------------------------------------------
# Database helpers (parameterized queries only - no string-built SQL)
# --------------------------------------------------------------------------
def get_db():
    from flask import current_app
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    with open(os.path.join(BASE_DIR, "schema.sql"), encoding="utf-8") as f:
        get_db().executescript(f.read())


# --------------------------------------------------------------------------
# Validation helpers
# --------------------------------------------------------------------------
def clean(value):
    return (value or "").strip()


def parse_int(raw, label, minimum=0, maximum=MAX_QTY):
    raw = clean(raw)
    if raw == "":
        return None, f"{label} is required."
    try:
        number = int(raw)
    except ValueError:
        return None, f"{label} must be a whole number."
    if number < minimum or number > maximum:
        return None, f"{label} must be between {minimum} and {maximum}."
    return number, None


def validate_item_form(form):
    errors = []
    data = {
        "sku": clean(form.get("sku")).upper(),
        "name": clean(form.get("name")),
        "category": clean(form.get("category")) or "General",
        "unit": clean(form.get("unit")) or "pcs",
    }
    for field, label in (("sku", "SKU"), ("name", "Name"),
                         ("category", "Category"), ("unit", "Unit")):
        if len(data[field]) > MAX_TEXT:
            errors.append(f"{label} must be at most {MAX_TEXT} characters.")
    if not data["sku"]:
        errors.append("SKU is required.")
    if not data["name"]:
        errors.append("Name is required.")
    qty, err = parse_int(form.get("quantity", "0"), "Quantity")
    if err:
        errors.append(err)
    data["quantity"] = qty
    level, err = parse_int(form.get("reorder_level", "0"), "Reorder level")
    if err:
        errors.append(err)
    data["reorder_level"] = level
    return data, errors


# --------------------------------------------------------------------------
# Auth decorators and request hooks
# --------------------------------------------------------------------------
def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            flash("Please log in to continue.", "error")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if g.user["role"] != "admin":
            abort(403)
        return view(*args, **kwargs)
    return wrapped


def register_hooks(app):
    @app.before_request
    def load_user_and_check_csrf():
        user_id = session.get("user_id")
        g.user = None
        if user_id is not None:
            g.user = get_db().execute(
                "SELECT id, username, role FROM users WHERE id = ?", (user_id,)
            ).fetchone()
        if request.method == "POST" and app.config["CSRF_ENABLED"]:
            token = session.get("csrf_token")
            if not token or token != request.form.get("csrf_token"):
                abort(400)

    @app.context_processor
    def inject_globals():
        if "csrf_token" not in session:
            session["csrf_token"] = secrets.token_hex(16)
        return {"csrf_token": session["csrf_token"], "version": __version__}

    @app.after_request
    def security_headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        return resp

    @app.errorhandler(400)
    def bad_request(_e):
        return render_template("error.html", code=400,
                               message="The request could not be processed. "
                                       "Please go back and try again."), 400

    @app.errorhandler(403)
    def forbidden(_e):
        return render_template("error.html", code=403,
                               message="You do not have permission to do that."), 403

    @app.errorhandler(404)
    def not_found(_e):
        return render_template("error.html", code=404,
                               message="That page or record was not found."), 404

    @app.errorhandler(500)
    def server_error(e):
        app.logger.error("Unhandled error: %s", type(e).__name__)
        return render_template("error.html", code=500,
                               message="Something went wrong on our side. "
                                       "Please try again later."), 500


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------
def register_routes(app):

    # ---- Authentication --------------------------------------------------
    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            username = clean(request.form.get("username")).lower()
            password = request.form.get("password") or ""
            errors = []
            if not (3 <= len(username) <= 30) or not username.replace("_", "").isalnum():
                errors.append("Username must be 3-30 letters, numbers or underscores.")
            if len(password) < 8:
                errors.append("Password must be at least 8 characters.")
            db = get_db()
            if not errors and db.execute(
                    "SELECT 1 FROM users WHERE username = ?", (username,)).fetchone():
                errors.append("That username is already taken.")
            if errors:
                for e in errors:
                    flash(e, "error")
                return render_template("register.html", username=username), 400
            # First account becomes the admin; later accounts are staff.
            is_first = db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0
            db.execute(
                "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                (username, generate_password_hash(password),
                 "admin" if is_first else "staff"))
            db.commit()
            flash("Account created. Please log in.", "success")
            return redirect(url_for("login"))
        return render_template("register.html", username="")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = clean(request.form.get("username")).lower()
            password = request.form.get("password") or ""
            user = get_db().execute(
                "SELECT * FROM users WHERE username = ?", (username,)).fetchone()
            if user is None or not check_password_hash(user["password_hash"], password):
                app.logger.info("Failed login attempt")
                flash("Invalid username or password.", "error")
                return render_template("login.html", username=username), 401
            session.clear()
            session["user_id"] = user["id"]
            session["csrf_token"] = secrets.token_hex(16)
            return redirect(url_for("dashboard"))
        return render_template("login.html", username="")

    @app.route("/logout", methods=["POST"])
    def logout():
        session.clear()
        flash("You have been logged out.", "success")
        return redirect(url_for("login"))

    # ---- Dashboard -------------------------------------------------------
    @app.route("/")
    @login_required
    def dashboard():
        db = get_db()
        stats = db.execute(
            "SELECT COUNT(*) AS total_items, COALESCE(SUM(quantity), 0) AS total_units, "
            "COALESCE(SUM(quantity <= reorder_level), 0) AS low_count FROM items"
        ).fetchone()
        low = db.execute(
            "SELECT * FROM items WHERE quantity <= reorder_level "
            "ORDER BY quantity ASC, name LIMIT 5").fetchall()
        recent = db.execute(
            "SELECT m.*, i.name AS item_name, u.username FROM stock_movements m "
            "JOIN items i ON i.id = m.item_id JOIN users u ON u.id = m.user_id "
            "ORDER BY m.id DESC LIMIT 5").fetchall()
        return render_template("dashboard.html", stats=stats, low=low, recent=recent)

    # ---- Items (CRUD) ----------------------------------------------------
    @app.route("/items")
    @login_required
    def items():
        q = clean(request.args.get("q"))
        category = clean(request.args.get("category"))
        sql = "SELECT * FROM items WHERE 1=1"
        params = []
        if q:
            sql += " AND (name LIKE ? OR sku LIKE ?)"
            params += [f"%{q}%", f"%{q}%"]
        if category:
            sql += " AND category = ?"
            params.append(category)
        sql += " ORDER BY name"
        db = get_db()
        rows = db.execute(sql, params).fetchall()
        cats = [r[0] for r in db.execute(
            "SELECT DISTINCT category FROM items ORDER BY category")]
        return render_template("items.html", items=rows, q=q,
                               category=category, categories=cats)

    @app.route("/items/new", methods=["GET", "POST"])
    @admin_required
    def item_new():
        return item_form(None)

    @app.route("/items/<int:item_id>/edit", methods=["GET", "POST"])
    @admin_required
    def item_edit(item_id):
        item = get_item_or_404(item_id)
        return item_form(item)

    def item_form(item):
        db = get_db()
        if request.method == "POST":
            data, errors = validate_item_form(request.form)
            if not errors:
                dup = db.execute(
                    "SELECT id FROM items WHERE sku = ?", (data["sku"],)).fetchone()
                if dup and (item is None or dup["id"] != item["id"]):
                    errors.append("That SKU already exists.")
            if errors:
                for e in errors:
                    flash(e, "error")
                return render_template("item_form.html", item=request.form,
                                       editing=item is not None), 400
            if item is None:
                cur = db.execute(
                    "INSERT INTO items (sku, name, category, unit, quantity, reorder_level) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (data["sku"], data["name"], data["category"], data["unit"],
                     data["quantity"], data["reorder_level"]))
                if data["quantity"] > 0:
                    db.execute(
                        "INSERT INTO stock_movements (item_id, user_id, movement_type, "
                        "quantity, note) VALUES (?, ?, 'IN', ?, 'Opening stock')",
                        (cur.lastrowid, g.user["id"], data["quantity"]))
                db.commit()
                flash("Item added.", "success")
                return redirect(url_for("item_detail", item_id=cur.lastrowid))
            # Quantity is changed only via stock movements, never by editing.
            db.execute(
                "UPDATE items SET sku=?, name=?, category=?, unit=?, reorder_level=? "
                "WHERE id=?",
                (data["sku"], data["name"], data["category"], data["unit"],
                 data["reorder_level"], item["id"]))
            db.commit()
            flash("Item updated.", "success")
            return redirect(url_for("item_detail", item_id=item["id"]))
        return render_template("item_form.html", item=item or {},
                               editing=item is not None)

    def get_item_or_404(item_id):
        item = get_db().execute(
            "SELECT * FROM items WHERE id = ?", (item_id,)).fetchone()
        if item is None:
            abort(404)
        return item

    @app.route("/items/<int:item_id>")
    @login_required
    def item_detail(item_id):
        item = get_item_or_404(item_id)
        moves = get_db().execute(
            "SELECT m.*, u.username FROM stock_movements m "
            "JOIN users u ON u.id = m.user_id WHERE m.item_id = ? "
            "ORDER BY m.id DESC LIMIT 50", (item_id,)).fetchall()
        return render_template("item_detail.html", item=item, moves=moves)

    @app.route("/items/<int:item_id>/delete", methods=["POST"])
    @admin_required
    def item_delete(item_id):
        get_item_or_404(item_id)
        db = get_db()
        db.execute("DELETE FROM stock_movements WHERE item_id = ?", (item_id,))
        db.execute("DELETE FROM items WHERE id = ?", (item_id,))
        db.commit()
        flash("Item deleted.", "success")
        return redirect(url_for("items"))

    # ---- Stock in / out --------------------------------------------------
    @app.route("/items/<int:item_id>/stock", methods=["POST"])
    @login_required
    def stock_move(item_id):
        item = get_item_or_404(item_id)
        mtype = clean(request.form.get("movement_type")).upper()
        note = clean(request.form.get("note"))[:200]
        qty, err = parse_int(request.form.get("quantity"), "Quantity", minimum=1)
        if mtype not in ("IN", "OUT"):
            err = err or "Choose Stock In or Stock Out."
        if err:
            flash(err, "error")
            return redirect(url_for("item_detail", item_id=item_id)), 303
        db = get_db()
        if mtype == "IN":
            if item["quantity"] + qty > MAX_QTY:
                flash(f"Stock cannot exceed {MAX_QTY}.", "error")
                return redirect(url_for("item_detail", item_id=item_id))
            db.execute("UPDATE items SET quantity = quantity + ? WHERE id = ?",
                       (qty, item_id))
        else:
            # Atomic guard: the WHERE clause prevents negative stock.
            cur = db.execute(
                "UPDATE items SET quantity = quantity - ? WHERE id = ? AND quantity >= ?",
                (qty, item_id, qty))
            if cur.rowcount == 0:
                db.rollback()
                flash(f"Not enough stock. Only {item['quantity']} {item['unit']} available.",
                      "error")
                return redirect(url_for("item_detail", item_id=item_id))
        db.execute(
            "INSERT INTO stock_movements (item_id, user_id, movement_type, quantity, note) "
            "VALUES (?, ?, ?, ?, ?)", (item_id, g.user["id"], mtype, qty, note))
        db.commit()
        flash("Stock updated.", "success")
        updated = get_item_or_404(item_id)
        if updated["quantity"] <= updated["reorder_level"]:
            flash(f"Low stock: {updated['name']} is at or below its reorder level.",
                  "warning")
        return redirect(url_for("item_detail", item_id=item_id))

    @app.route("/movements")
    @login_required
    def movements():
        rows = get_db().execute(
            "SELECT m.*, i.name AS item_name, i.unit, u.username FROM stock_movements m "
            "JOIN items i ON i.id = m.item_id JOIN users u ON u.id = m.user_id "
            "ORDER BY m.id DESC LIMIT 200").fetchall()
        return render_template("movements.html", moves=rows)

    # ---- Reports ---------------------------------------------------------
    @app.route("/reports/low-stock")
    @login_required
    def report_low_stock():
        rows = get_db().execute(
            "SELECT * FROM items WHERE quantity <= reorder_level "
            "ORDER BY (reorder_level - quantity) DESC, name").fetchall()
        return render_template("report.html", items=rows)

    @app.route("/reports/inventory.csv")
    @login_required
    def export_csv():
        rows = get_db().execute(
            "SELECT sku, name, category, unit, quantity, reorder_level "
            "FROM items ORDER BY name").fetchall()
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(["SKU", "Name", "Category", "Unit", "Quantity",
                         "Reorder level", "Status"])
        for r in rows:
            status = "LOW" if r["quantity"] <= r["reorder_level"] else "OK"
            # Prefix formula-like text so spreadsheets do not execute it.
            safe = [("'" + str(v)) if str(v)[:1] in "=+-@" and str(v) else v
                    for v in (r["sku"], r["name"], r["category"], r["unit"])]
            writer.writerow(safe + [r["quantity"], r["reorder_level"], status])
        return Response(buf.getvalue(), mimetype="text/csv", headers={
            "Content-Disposition": "attachment; filename=inventory_report.csv"})


app = create_app() if os.environ.get("FLASK_APP_AUTOCREATE") else None

if __name__ == "__main__":
    create_app().run(debug=os.environ.get("FLASK_DEBUG") == "1")
