# Changelog

Format follows [Semantic Versioning](https://semver.org/).

## [1.0.0] - MVP release
### Added
- Registration, login, logout; first account becomes admin, later accounts are staff
- Item records (create, edit, delete, search, filter by category)
- Stock In / Stock Out logging with a full movement history
- Low-stock alerts on the dashboard, after stock-out, and in a report
- CSV export of the inventory
- Server-side validation, CSRF protection, hashed passwords, friendly error pages
- Automated test suite (pytest)
