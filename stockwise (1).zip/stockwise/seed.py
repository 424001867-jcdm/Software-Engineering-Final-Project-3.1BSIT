"""Load FICTIONAL sample data for demos. Never use real personal data.

Usage:  python seed.py
Creates demo accounts (dummy credentials, for local use only):
    admin_demo / DemoPass123   (admin)
    staff_demo / DemoPass123   (staff)
"""
from werkzeug.security import generate_password_hash

from app import create_app, get_db

ITEMS = [
    ("PAP-A4", "A4 Bond Paper (ream)", "Office", "ream", 40, 10),
    ("PEN-BLK", "Black Ballpen", "Office", "pcs", 8, 20),
    ("MRK-WB", "Whiteboard Marker", "Classroom", "pcs", 25, 12),
    ("CHL-WHT", "White Chalk (box)", "Classroom", "box", 3, 5),
    ("GLV-L", "Lab Gloves (box)", "Laboratory", "box", 15, 6),
    ("BKR-250", "Beaker 250 ml", "Laboratory", "pcs", 12, 4),
    ("TAP-CLR", "Clear Tape", "Office", "roll", 0, 6),
]


def main():
    app = create_app()
    with app.app_context():
        db = get_db()
        if db.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
            print("Database already has data; nothing seeded.")
            return
        pw = generate_password_hash("DemoPass123")
        db.execute("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'admin')",
                   ("admin_demo", pw))
        db.execute("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'staff')",
                   ("staff_demo", pw))
        for sku, name, cat, unit, qty, level in ITEMS:
            cur = db.execute(
                "INSERT INTO items (sku, name, category, unit, quantity, reorder_level) "
                "VALUES (?, ?, ?, ?, ?, ?)", (sku, name, cat, unit, qty, level))
            if qty:
                db.execute(
                    "INSERT INTO stock_movements (item_id, user_id, movement_type, quantity, note) "
                    "VALUES (?, 1, 'IN', ?, 'Opening stock')", (cur.lastrowid, qty))
        db.commit()
        print("Seeded demo users and sample items.")


if __name__ == "__main__":
    main()
